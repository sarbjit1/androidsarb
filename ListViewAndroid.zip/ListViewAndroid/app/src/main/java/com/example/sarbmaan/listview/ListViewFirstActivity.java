package com.example.sarbmaan.listview;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.List;

public class ListViewFirstActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_view_first);


       // String[] students = {"Pink","Red","Green","Yallow","Orange","purple","White","Cream","lightGreen"};

      //  listView Studentslist= (ListView)findViewById(R.id.Student_list);

      /*  AgentDAO dao = new AgentDAO(this);
        List<Agents> agents = dao.dbSearch();
        dao.close();

        ListView agentList = (ListView)findViewById(R.id.agent_list);


        ArrayAdapter<Agents> adapter = new ArrayAdapter<Agents>(this, android.R.layout.simple_list_item_1 , agents);
        ListView studentList = (ListView)findViewById(R.id.Student_list);

       agentList.setAdapter(adapter); */

        Button addNew = (Button)findViewById(R.id.Plusclick);
        addNew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentGoTo = new Intent(ListViewFirstActivity.this ,PressPlus.class);
                startActivity(intentGoTo);
            }
        });


    }
    private void loadAgentsList(){
        AgentDAO dao = new AgentDAO(this);
        List<Agents> agents = dao.dbSearch();
        dao.close();

        ListView agentList = (ListView)findViewById(R.id.agent_list);


        ArrayAdapter<Agents> adapter = new ArrayAdapter<Agents>(this, android.R.layout.simple_list_item_1 , agents);
        //ListView studentList = (ListView)findViewById(R.id.Student_list);
        // ListView agentlist = (ListView)findViewById(R.id.agent_list) ;
        agentList.setAdapter(adapter);

    }
    protected void onResume(){
        loadAgentsList();
        super.onResume();
    }
}
