package com.example.sarbmaan.listview;

import android.widget.EditText;

/**
 * Created by sarbmaan on 2017-12-05.
 */

public class plushealper {
    private  EditText fildName;
    private  EditText fildphone;
    private  EditText fildaddress;
    private  EditText fildemail;

    public plushealper(PressPlus plus){
        fildName = (EditText)plus.findViewById(R.id.textName);
        fildphone = (EditText)plus.findViewById(R.id.textphone);
        fildaddress = (EditText)plus.findViewById(R.id.textAdress);
        fildemail = (EditText)plus.findViewById(R.id.textEmail);


    }
    public Agents helperAgents(){
        Agents ag = new Agents();
        ag.setName(fildName.getText().toString());
        ag.setPhone(fildphone.getText().toString());
        ag.setAdrees(fildaddress.getText().toString());
        ag.setEmail(fildemail.getText().toString());
        return ag;

    }

}
