package com.example.sarbmaan.listview;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by sarbmaan on 2017-12-05.
 */

public class AgentDAO extends SQLiteOpenHelper{
    public AgentDAO(Context context) {
        super(context, "myAgentDB", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "CREATE TABLE Agents (id INTEGER PRIMARY KEY , name TEXT NOT NULL, phone TEXT , adrees TEXT , email TEXT)";
        db.execSQL(sql);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersio, int newVersion) {
        String sql = "DROP TABLE IF EXISTS Agents";
        db.execSQL(sql);
        onCreate(db);



    }

    public void dbinsert(Agents ag){
        SQLiteDatabase db = getWritableDatabase();

        ContentValues agentdata = new ContentValues();
        agentdata.put("name",ag.getName());
        agentdata.put("phone",ag.getPhone());
        agentdata.put("adrees",ag.getAdrees());
        agentdata.put("email",ag.getEmail());

        db.insert("Agents",null,agentdata);

    }

    public List<Agents> dbSearch(){
        SQLiteDatabase db = getReadableDatabase();
        String sql = "SELECT * FROM Agents";

        Cursor C = db.rawQuery(sql, null);

        List<Agents> AgentsList = new ArrayList<Agents>();


        while(C.moveToNext()){
            Agents ag = new Agents();

            ag.setId(C.getLong(C.getColumnIndex("id")));
            ag.setName(C.getString(C.getColumnIndex("name")));
            ag.setPhone(C.getString(C.getColumnIndex("phone")));
            ag.setAdrees(C.getString(C.getColumnIndex("adrees")));
            ag.setEmail(C.getString(C.getColumnIndex("email")));

            AgentsList.add(ag);

        }
        C.close();
        return AgentsList;
    }


}
